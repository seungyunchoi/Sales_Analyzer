import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class GUI extends JFrame
{
       JPanel panel = new JPanel();
       JTextArea textArea = new JTextArea(10,45);
       JScrollPane display = new JScrollPane(textArea);
       
       //raw sql ( runs sql query entered)
       JTextField textfield_sql = new JTextField(30); // add text field for user input
       JButton button_sql = new JButton("SQL"); // add button with name of command
       
       // jdb show related tables
       JTextField textfield_rel = new JTextField(30);
       JButton button_rel= new JButton("Show Related Tables");
       
       //jdb search path
       JTextField textfield_path = new JTextField(30);
       JButton button_path = new JButton("Search Path");
       
       //jdb search and join
       JTextField textfield_join = new JTextField(30);
       JButton button_join = new JButton("Search and Join");
       
       // jdb stat
       JTextField textfield_stat = new JTextField(30);
       JButton button_stat = new JButton("STAT");
       
       // jdb show primary keys
       JButton button_keys = new JButton("Show Primary Keys");
       
       //jdb customers by city
       JButton button_customer_city = new JButton("Customers by City");
       
       //jdb find column
       JTextField textfield_col = new JTextField(30);
       JButton button_col = new JButton("Find Column");
       
       //jdb show customer sales

       JButton button_sales = new JButton("Show Customer Sales");
       
       //jdb show top spenders (has optional parameter for how many you want to see)
       JTextField textfield_spend = new JTextField(30);
       JButton button_spend = new JButton("Show Top Spenders");
       
       //jdb show product ratings
       JButton button_rate = new JButton("Show Product Ratings");
       
       //jdb get view
       JTextField textfield_view = new JTextField(30);
       JButton button_view = new JButton("Get View");
       
       //jdb get products per city
       JTextField textfield_product_city = new JTextField(30);
       JButton button_product_city = new JButton("Products Per City");
       
       JButton button_schem = new JButton("Show Schema");
       String input = "";
       
       
       

       public GUI()
       {
              setTitle("Entry");
              setVisible(true);
              setSize(600, 600); // size of window
              textArea.setEditable(false);
              display.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS ); // add scroll bar to display
              
              
              setDefaultCloseOperation(EXIT_ON_CLOSE);
              
              // COMMAND 1: raw sql
              panel.add(textfield_sql); // add text field
              
              // Can press enter on keyboard
              textfield_sql.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_sql.getText();
                           args[0] = input; // sql query input from user
                           textArea.setText(JDBCCmdLine.getResults(args)); // display returned string from JDBCCmdLine.getResults Function onto the Window
                           textfield_sql.setText(""); // empty the text field after user has entered parameters
                     }
              });

              // Can press button
              panel.add(button_sql); // add button
              button_sql.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_sql.getText();
                            args[0] = input; // sql query input from user
                            //textfield_sql.setText(input);
                            textArea.setText(JDBCCmdLine.getResults(args)); // display returned string from JDBCCmdLine.getResults Function onto the Window
                            textfield_sql.setText(""); // empty the text field after user has entered parameters
                      }
              });
              
              
              
              
              
              
              // COMMAND 2: jdb show related tables
              panel.add(textfield_rel);
           // Can press enter on keyboard
              textfield_rel.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_rel.getText(); // get parameter input from user
                           args[0] = "jdb-show-related-table " + input; // append parameters and command name
                           textArea.setText(JDBCCmdLine.getResults(args)); // display returned string from JDBCCmdLine.getResults Function onto the Window
                           textfield_rel.setText(""); // empty the text field after user has entered parameters
                     }
              });

              // Can press button
              panel.add(button_rel); // add button
              button_rel.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_rel.getText();
                            args[0] = "jdb-show-related-table " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_rel.setText(""); // empty the text field after user has entered parameters
                      }
              });
              
              
              
              //COMMAND 3: jdb search path
              panel.add(textfield_path);
           // Can press enter on keyboard
              textfield_path.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_path.getText();
                           args[0] = "jdb-search-path " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_path.setText("");
                     }
              });

              // Can press button
              panel.add(button_path); // add button
              button_path.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_path.getText();
                            args[0] = "jdb-search-path " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_path.setText("");
                      }
              });
              
              
              
             //COMMAND 4: jdb search and join
              panel.add(textfield_join);
           // Can press enter on keyboard
              textfield_join.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_join.getText();
                           args[0] = "jdb-search-and-join " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_join.setText("");
                     }
              });

              // Can press button
              panel.add(button_join); // add button
              button_join.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_join.getText();
                            args[0] = "jdb-search-and-join " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_join.setText("");
                      }
              });
              
              
              
             //COMMAND 5: jdb-stat
              panel.add(textfield_stat);
           // Can press enter on keyboard
              textfield_stat.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_stat.getText();
                           args[0] = "jdb-stat " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_stat.setText("");
                     }
              });

              // Can press button
              panel.add(button_stat); // add button
              button_stat.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_stat.getText();
                            args[0] = "jdb-stat " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_stat.setText("");
                      }
              });
              

              
            //COMMAND 8: jdb find column
              panel.add(textfield_col);
           // Can press enter on keyboard
              textfield_col.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_col.getText();
                           args[0] = "jdb-find-column " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_col.setText("");
                     }
              });

              // Can press button
              panel.add(button_col); // add button
              button_col.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_col.getText();
                            args[0] = "jdb-find-column " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_col.setText("");
                      }
              });
              
              
              
             
            //COMMAND 10: jdb-show-top-spenders
              panel.add(textfield_spend);
           // Can press enter on keyboard
              textfield_spend.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_spend.getText();
                           args[0] = "jdb-show-top-spenders " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_spend.setText("");
                     }
              });

              // Can press button
              panel.add(button_spend); // add button
              button_spend.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_spend.getText();
                            args[0] = "jdb-show-top-spenders " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_spend.setText("");
                      }
              });
              
             

            //COMMAND 11: jdb get view
              panel.add(textfield_view);
           // Can press enter on keyboard
              textfield_view.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_view.getText();
                           args[0] = "jdb-get-view " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_view.setText("");
                     }
              });

              // Can press button
              panel.add(button_view); // add button
              button_view.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_view.getText();
                            args[0] = "jdb-get-view " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_view.setText("");
                      }
              });
              
              
              
            //COMMAND 11: jdb get products per city
              panel.add(textfield_product_city);
           // Can press enter on keyboard
              textfield_product_city.addActionListener(new ActionListener()
              {
                     public void actionPerformed(ActionEvent e)
                     {
                    	 String args [] = new String[1];
                           input = textfield_product_city.getText();
                           args[0] = "jdb-get-products-per-city " + input;
                           textArea.setText(JDBCCmdLine.getResults(args));
                           textfield_product_city.setText("");
                     }
              });

              // Can press button
              panel.add(button_product_city); // add button
              button_product_city.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            input = textfield_product_city.getText();
                            args[0] = "jdb-get-products-per-city " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                            textfield_product_city.setText("");
                      }
              });
              
              
              
              //ALL COMMANDS WITH NO PARAMETERS
              
              //COMMAND 6: jdb show all primary keys

              // Can press button
              panel.add(button_keys); // add button
              button_keys.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            args[0] = "jdb-show-all-primary-keys";
                            textArea.setText(JDBCCmdLine.getResults(args));
                      }
              });
              
              
              
              //COMMAND 9: jdb show customer sales

              // Can press button
              panel.add(button_sales); // add button
              button_sales.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            args[0] = "jdb-show-customer-sales";
                            textArea.setText(JDBCCmdLine.getResults(args));
                      }
              });
              
              //COMMAND 7: jdb  customers by city
              // Can press button 
              panel.add(button_customer_city); // add button
              button_customer_city.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            args[0] = "jdb-customers-by-city " + input;
                            textArea.setText(JDBCCmdLine.getResults(args));
                      }
              });
            
              
              //COMMAND 11: jdb show product ratings

              // Can press button
              panel.add(button_rate); // add button
              button_rate.addActionListener(new ActionListener()
              {
                      public void actionPerformed(ActionEvent e)
                      {
                    	  	String args [] = new String[1];
                            args[0] = "jdb-show-product-ratings";
                            textArea.setText(JDBCCmdLine.getResults(args));
                      }
              });
              panel.add(button_schem);
              button_schem.addActionListener(new ActionListener()
              {
            	  public void actionPerformed(ActionEvent e) 
            	  {
            		  DbSchema.main(null);
            		  textArea.setText("Check Schem.pdf");
            	  }
              });

              
              
              panel.add(display); // add scroll bar to panel
              add(panel); // add panel to the window
              
              
              

       }

       public static void main(String[] args)
       {
             GUI t = new GUI(); // create GUI object 
       }
}